"""
Simple 2-D acoustic TLM model based on Kagawa et al. (1998),
Sections 2.1, 2.3 and 2.4.

Port convention:
    0 = left, 1 = up, 2 = right, 3 = down

Main modelling choices (and why):
  * Branch propagation speed is chosen so that the NETWORK wave speed
    c_T = c_branch/sqrt(2) equals the physical speed of sound c0
    (Kagawa Eq. 11). So dt = dx / (sqrt(2)*c0).
  * Nodes are cell-centred: the walls sit at the ends of the outermost
    branches, i.e. half a cell outside the outermost nodes (Kagawa Fig. 7).
    The pipe therefore has exactly length x width = nx*dx x ny*dx.
  * The reflection coefficient R given to the model is the BRANCH reflection
    coefficient of Kagawa Eq. (24). The reflection coefficient G actually
    seen by a wave travelling in the network follows from Eq. (23); the
    standing-wave measurement in tasks 5-7 gives |G|, not R.
  * The source is ADDED to the incident pulse on one branch (soft source),
    so that pulses reflected back onto that branch are not erased.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks


# ============================================================
# SETTINGS
# ============================================================

C0 = 343.0                  # speed of sound in air at 20 degC [m/s]
RHO0 = 1.204                # air density at 20 degC [kg/m^3] (kept for Eq. 26)

LENGTH = 2.0                # pipe length [m]
WIDTH = 0.2                 # pipe width [m]
DX = 0.01                   # mesh spacing [m]  (~17 points/wavelength at 2 kHz)

# Branch reflection coefficient R at the pipe ends (Kagawa Eq. 24).
# R = 1 is a rigid wall.
R_WALL = 1.0

# Source / simulation settings
F_START = 100.0
F_STOP = 2000.0
SWEEP_DURATION = 2.0        # [s] nominal; adjusted slightly so sweep ends at a zero crossing
RINGDOWN = 0.3              # [s] zeros appended after the sweep so the pipe can ring down
DIRAC_DURATION = 1.0        # [s] simulated time for the Dirac-pulse run
SIMULATION_DURATION = 0.5   # [s] simulated time for harmonic runs (tasks 3-7)


# ============================================================
# REFLECTION COEFFICIENT CONVERSION
# ============================================================

def wall_to_branch_reflection(G):
    """
    Network (wall) reflection coefficient G  ->  branch coefficient R.
    Kagawa Eq. (23). G = 1 gives R = 1, G = 0 gives R = (1-sqrt2)/(1+sqrt2)
    (Eq. 25, non-reflecting end for normal incidence).
    """
    G = np.asarray(G, dtype=float)
    r2 = np.sqrt(2.0)
    return ((1.0 + G) - r2 * (1.0 - G)) / ((1.0 + G) + r2 * (1.0 - G))


def branch_to_wall_reflection(R):
    """
    Inverse of Eq. (23): branch coefficient R -> network reflection
    coefficient G. This is the value the standing-wave ratio should give,
    e.g. R = 0.3 gives G ~ 0.45.
    """
    R = np.asarray(R, dtype=float)
    r2 = np.sqrt(2.0)
    return (r2 * (1.0 + R) - (1.0 - R)) / (r2 * (1.0 + R) + (1.0 - R))


# ============================================================
# EXCITATION SIGNALS
# ============================================================

def linear_sweep_zero_crossings(dt, f1=F_START, f2=F_STOP, duration=SWEEP_DURATION):
    """
    Linear sine sweep x(t) = sin(2*pi*(f1*t + (f2-f1)/(2T) * t^2)).

    The sweep starts at t = 0 (sin = 0). The total phase at t = T is
    T*(f1+f2)/2 cycles; to end at a zero crossing this must be an integer.
    We therefore (1) make T an exact multiple of dt and (2) round the number
    of cycles to an integer by adjusting f2 very slightly.

    Returns t, signal, f2_used, T_used.
    """
    n = int(round(duration / dt))
    T = n * dt
    cycles = round(T * (f1 + f2) / 2.0)
    f2_used = 2.0 * cycles / T - f1
    t = np.arange(n + 1) * dt
    phase_cycles = f1 * t + (f2_used - f1) * t**2 / (2.0 * T)
    return t, np.sin(2.0 * np.pi * phase_cycles), f2_used, T


def dirac_pulse(n_steps, amplitude=1.0):
    """One-time-step approximation to a Dirac pulse."""
    signal = np.zeros(n_steps)
    signal[0] = amplitude
    return signal


def harmonic_source(t, frequency, amplitude=1.0, ramp_time=0.0):
    """
    Continuous harmonic excitation. An optional smooth fade-in (ramp_time [s])
    reduces the broadband start-up transient, which in a lossless pipe
    otherwise never dies out and disturbs the steady-state measurement.
    """
    s = amplitude * np.sin(2.0 * np.pi * frequency * t)
    if ramp_time > 0.0:
        fade = np.clip(t / ramp_time, 0.0, 1.0)
        s = s * 0.5 * (1.0 - np.cos(np.pi * fade))
    return s


# ============================================================
# TLM MODEL
# ============================================================

class TLM2D:
    def __init__(self, length=LENGTH, width=WIDTH, dx=DX, c0=C0, rho0=RHO0,
                 R_left=R_WALL, R_right=R_WALL):
        self.length = float(length)
        self.width = float(width)
        self.dx = float(dx)
        self.c0 = float(c0)
        self.rho0 = float(rho0)

        # Cell-centred nodes: nx x ny cells, one node in each cell centre.
        nx_f = self.length / self.dx
        ny_f = self.width / self.dx
        self.nx = int(round(nx_f))
        self.ny = int(round(ny_f))
        if abs(nx_f - self.nx) > 1e-6 or abs(ny_f - self.ny) > 1e-6:
            raise ValueError("Length and width must be integer multiples of dx.")

        # Node coordinates (cell centres). Walls are at x = 0, x = length,
        # y = 0 and y = width.
        self.x = (np.arange(self.nx) + 0.5) * self.dx
        self.y = (np.arange(self.ny) + 0.5) * self.dx

        # Time for a pulse to travel one branch length dx. The branch speed is
        # sqrt(2)*c0 so that the network speed c_T = c_branch/sqrt(2) = c0
        # (Kagawa Eq. 11).
        self.dt = self.dx / (np.sqrt(2.0) * self.c0)
        self.time = None

        # Branch reflection coefficients of the outward-facing ports.
        # Left/right: pipe ends (R). Up/down: rigid side walls (R = 1).
        self.R_left = float(R_left)
        self.R_right = float(R_right)
        self.R_top = 1.0
        self.R_bottom = 1.0

        # Kagawa Sec. 2.4 loss parameter z at every node. Zero = lossless.
        self.loss_z = np.zeros((self.nx, self.ny), dtype=float)

        # Incident pulses at each node: [port, x, y].
        self.P = np.zeros((4, self.nx, self.ny), dtype=float)

    # ---- boundary setup -------------------------------------------------

    def set_branch_reflection(self, R_left, R_right=None):
        """Set the branch reflection coefficient R (Eq. 24) at the pipe ends."""
        self.R_left = float(R_left)
        self.R_right = float(R_left if R_right is None else R_right)

    def set_wall_reflection(self, G_left, G_right=None):
        """Set the network reflection coefficient G; converted to R by Eq. (23)."""
        G_right = G_left if G_right is None else G_right
        self.R_left = float(wall_to_branch_reflection(G_left))
        self.R_right = float(wall_to_branch_reflection(G_right))

    # ---- loss setup -----------------------------------------------------

    def set_loss_region(self, x_start, z, ramp=False, power=2.0):
        """
        Distributed loss z (Kagawa Eq. 31) for all nodes with x >= x_start.

        ramp=False : constant z in the region (abrupt impedance step).
        ramp=True  : z grows as (distance from x_start)**power, from 0 at
                     x_start to z at the right end. This reduces the
                     reflection at the transition. power=1 is a linear
                     ramp, power=2 a quadratic one.
        """
        self.loss_z[:] = 0.0
        inside = self.x >= x_start
        if ramp:
            s = (self.x[inside] - x_start) / (self.length - x_start)
            self.loss_z[inside, :] = float(z) * (s**power)[:, None]
        else:
            self.loss_z[inside, :] = float(z)

    # ---- time stepping --------------------------------------------------

    def reset(self):
        self.P.fill(0.0)

    def step(self, source_value=0.0, source_xy=(0, 0), source_port=0):
        """
        Advance the field by one time step and return the node pressure.

        The source is ADDED to the incident pulse on one branch. Default is
        port 0 (outward-facing left branch) of the lower-left corner node.
        """
        ix, iy = source_xy
        self.P[source_port, ix, iy] += source_value

        # Scattering. Lossless: p = 0.5*sum(P), S_n = p - P_n (Eqs. 1, 3).
        # With loss: p = 2*sum(P)/(4+z) (Eq. 31), still S_n = p - P_n.
        sum_P = np.sum(self.P, axis=0)
        p_node = 2.0 * sum_P / (4.0 + self.loss_z)
        S = p_node[np.newaxis, :, :] - self.P

        # Propagation to neighbouring nodes (Eq. 4).
        P_next = np.zeros_like(self.P)
        P_next[0, 1:, :] = S[2, :-1, :]   # left port  <- right port of left neighbour
        P_next[2, :-1, :] = S[0, 1:, :]   # right port <- left port of right neighbour
        P_next[1, :, :-1] = S[3, :, 1:]   # up port    <- down port of upper neighbour
        P_next[3, :, 1:] = S[1, :, :-1]   # down port  <- up port of lower neighbour

        # Boundaries: outward-facing branches reflect with R (Eq. 24).
        P_next[0, 0, :] = self.R_left * S[0, 0, :]
        P_next[2, -1, :] = self.R_right * S[2, -1, :]
        P_next[1, :, -1] = self.R_top * S[1, :, -1]
        P_next[3, :, 0] = self.R_bottom * S[3, :, 0]

        self.P = P_next
        return p_node

    def run(self, source, receiver_xy=None, snapshots_at=None,
            source_xy=(0, 0), source_port=0, record_line_y=None):
        """
        Run a simulation.

        source        : 1-D array, incident source pressure per time step.
        receiver_xy   : (ix, iy) of the receiver. Default: lower-right corner.
        snapshots_at  : iterable of time-step indices at which the full
                        pressure field is stored.
        record_line_y : None, an integer y-index, or "mean". If given, the
                        pressure along x is stored for every time step
                        ("mean" = average over the width, which cancels the
                        antisymmetric first transverse mode).
        Returns time, receiver, snapshots, line_history.
        """
        self.reset()
        source = np.asarray(source, dtype=float)
        n_steps = len(source)
        self.time = np.arange(n_steps) * self.dt

        if receiver_xy is None:
            receiver_xy = (self.nx - 1, 0)

        receiver = np.zeros(n_steps)
        snapshots = {}
        wanted = set(snapshots_at or [])

        line_history = None
        if record_line_y is not None:
            if record_line_y != "mean" and not (0 <= record_line_y < self.ny):
                raise ValueError("record_line_y is outside the grid.")
            line_history = np.zeros((n_steps, self.nx))

        for n in range(n_steps):
            p = self.step(source[n], source_xy, source_port)
            receiver[n] = p[receiver_xy]
            if line_history is not None:
                line_history[n, :] = (p.mean(axis=1) if record_line_y == "mean"
                                      else p[:, record_line_y])
            if n in wanted:
                snapshots[n] = p.copy()

        return self.time, receiver, snapshots, line_history


# ============================================================
# ANALYSIS
# ============================================================

def spectrum(signal, dt):
    """Single-sided amplitude spectrum (Hann-windowed)."""
    signal = np.asarray(signal)
    signal = signal - np.mean(signal)
    window = np.hanning(len(signal))
    spec = np.fft.rfft(signal * window)
    freq = np.fft.rfftfreq(len(signal), dt)
    amplitude = 2.0 * np.abs(spec) / np.sum(window)
    return freq, amplitude


def resonance_peaks(signal, dt, f_min=50.0, f_max=2000.0, prominence=0.01):
    """Prominent peaks in the receiver spectrum, returned sorted by frequency."""
    freq, amplitude = spectrum(signal, dt)
    mask = (freq >= f_min) & (freq <= f_max)
    f = freq[mask]
    a = amplitude[mask]
    if len(a) == 0:
        return np.array([]), np.array([])
    idx, _ = find_peaks(a, prominence=prominence * np.max(a))
    return f[idx], a[idx]          # find_peaks already returns increasing index


def theoretical_modes(length=LENGTH, width=WIDTH, c0=C0, f_max=2000.0, n_max=20):
    """
    Rigid rectangular-duct modes f_nm = (c0/2)*sqrt((n/L)^2 + (m/W)^2).
    Returns a list of (frequency, n, m) sorted by frequency, up to f_max.
    Corner receiver + corner source excite all of these (except (0,0)).
    """
    modes = []
    for n in range(0, n_max + 1):
        for m in range(0, n_max + 1):
            if n == 0 and m == 0:
                continue
            f = 0.5 * c0 * np.sqrt((n / length) ** 2 + (m / width) ** 2)
            if f <= f_max:
                modes.append((f, n, m))
    return sorted(modes)


def theoretical_axial_modes(length=LENGTH, c0=C0, n_modes=10):
    """Rigid-rigid axial modes (n,0): f_n = n*c0/(2L)."""
    return np.arange(1, n_modes + 1) * c0 / (2.0 * length)


def theoretical_first_transverse_mode(width=WIDTH, c0=C0):
    """Cut-on of the first transverse mode (0,1): c0/(2W)."""
    return c0 / (2.0 * width)


def harmonic_line_amplitude(line_history, dt, frequency, cycles_to_use=10):
    """
    Steady-state harmonic pressure amplitude at every x-position, from a
    sine/cosine/constant least-squares fit over the last cycles_to_use periods.
    """
    n_period = max(4, int(round(1.0 / (frequency * dt))))
    n_use = min(len(line_history), cycles_to_use * n_period)
    data = line_history[-n_use:, :]
    t = np.arange(n_use) * dt
    wt = 2.0 * np.pi * frequency * t
    A = np.column_stack((np.sin(wt), np.cos(wt), np.ones(n_use)))
    coeff, *_ = np.linalg.lstsq(A, data, rcond=None)
    return np.sqrt(coeff[0, :] ** 2 + coeff[1, :] ** 2)


def _refine_extremum(x, y, i):
    """
    Refine an extremum of y near index i with a parabola through three points.
    Used on amplitude**2, which is smooth (parabolic) around a pressure
    minimum, whereas the amplitude itself has a V-shaped cusp there.
    Returns (x_extremum, y_extremum).
    """
    if i <= 0 or i >= len(y) - 1:
        return x[i], y[i]
    y0, y1, y2 = y[i - 1], y[i], y[i + 1]
    denom = y0 - 2.0 * y1 + y2
    if denom == 0.0:
        return x[i], y1
    delta = 0.5 * (y0 - y2) / denom                 # offset in grid steps
    return x[i] + delta * (x[1] - x[0]), y1 - 0.25 * (y0 - y2) * delta


def standing_wave_ratio(x, amplitude, x_limit=None):
    """
    Find the two pressure minima closest to the right boundary (or to
    x_limit, if given), the maximum between them, and compute
        s = |pmax| / |pmin|  (first minimum, nearest the boundary),
        |r| = (s - 1)/(s + 1).
    x_limit lets you ignore a lossy extension (task 7): only x <= x_limit
    is analysed.

    The extrema are refined by parabolic interpolation on amplitude**2.
    Without this, the sampled minimum never gets close to zero (the mesh is
    dx = 1 cm), which would limit s and make |r| come out too low for a
    nearly rigid end.
    """
    if x_limit is not None:
        keep = x <= x_limit
        x, amplitude = x[keep], amplitude[keep]

    minima, _ = find_peaks(-amplitude)       # never returns the end points
    if len(minima) < 2:
        raise ValueError("Could not identify two pressure minima along the pipe.")

    minima = minima[np.argsort(x[minima])[::-1]]       # nearest boundary first
    i_min_1, i_min_2 = sorted(minima[:2])
    i_max = i_min_1 + int(np.argmax(amplitude[i_min_1:i_min_2 + 1]))

    a2 = amplitude**2
    x_min1, p2_min1 = _refine_extremum(x, a2, minima[0])
    x_min2, p2_min2 = _refine_extremum(x, a2, minima[1])
    x_max, p2_max = _refine_extremum(x, a2, i_max)

    p_min = np.sqrt(max(p2_min1, 1e-30))
    p_min2 = np.sqrt(max(p2_min2, 1e-30))
    p_max = np.sqrt(p2_max)
    s = p_max / p_min
    return {
        "first_minimum_x": x_min1,
        "first_minimum": p_min,
        "second_minimum_x": x_min2,
        "second_minimum": p_min2,
        "maximum_between_minima_x": x_max,
        "maximum": p_max,
        "SWR": s,
        "reflection_magnitude": (s - 1.0) / (s + 1.0),
    }


# ============================================================
# PLOTTING HELPERS
# ============================================================

def plot_receiver(time, signal, title="Receiver pressure"):
    plt.figure()
    plt.plot(time, signal)
    plt.xlabel("Time [s]")
    plt.ylabel("Pressure [relative units]")
    plt.title(title)
    plt.grid(True)
    plt.tight_layout()


def plot_spectrum(signal, dt, f_max=2000.0, title="Receiver spectrum", modes=None):
    """Receiver spectrum; optionally mark theoretical mode frequencies."""
    freq, amplitude = spectrum(signal, dt)
    mask = freq <= f_max
    plt.figure()
    plt.plot(freq[mask], amplitude[mask])
    if modes is not None:
        for f, n, m in modes:
            plt.axvline(f, color="r", ls=":", lw=0.7)
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("Amplitude [relative units]")
    plt.title(title)
    plt.grid(True)
    plt.tight_layout()


def plot_axis_pressure(model, pressure_field, label=None):
    """Plot pressure along the pipe centre line (adds to the current figure)."""
    iy = model.ny // 2
    plt.plot(model.x, pressure_field[:, iy], label=label)
    plt.xlabel("x [m]")
    plt.ylabel("Pressure [relative units]")
    plt.grid(True)


# ============================================================
# TASKS (each one is a small, self-contained function)
# ============================================================

def task1_sweep():
    """Task 1: linear sweep, lower-left source, lower-right receiver."""
    model = TLM2D()
    t, source, f2_used, T = linear_sweep_zero_crossings(model.dt)
    # Append zeros so the pipe can ring down after the sweep has ended.
    source = np.concatenate((source, np.zeros(int(round(RINGDOWN / model.dt)))))
    time, receiver, _, _ = model.run(source)

    print(f"Grid: {model.nx} x {model.ny} nodes, dx = {model.dx} m, dt = {model.dt:.3e} s")
    print(f"Sweep: {F_START:.1f} -> {f2_used:.3f} Hz in {T:.4f} s (ends at zero crossing)")

    f_peaks, a_peaks = resonance_peaks(receiver, model.dt)
    modes = theoretical_modes()
    print("\nReceiver-spectrum peaks [Hz]:")
    print(np.round(f_peaks, 1))
    print("\nTheory, rigid duct (f, n, m):")
    for f, n, m in modes:
        print(f"  {f:8.2f} Hz   ({n},{m})")
    print(f"\nFirst transverse cut-on: {theoretical_first_transverse_mode():.1f} Hz")
    print("Note: (1,0) = 85.7 Hz lies below the sweep start (100 Hz).")

    plot_receiver(time, receiver, "Linear sweep: lower-right receiver")
    plot_spectrum(receiver, model.dt, title="Sweep: receiver spectrum", modes=modes)
    return f_peaks


def task2_dirac():
    """Task 2: Dirac pulse instead of the sweep."""
    model = TLM2D()
    n_steps = int(round(DIRAC_DURATION / model.dt))
    time, receiver, _, _ = model.run(dirac_pulse(n_steps))
    f_peaks, _ = resonance_peaks(receiver, model.dt)
    print("Dirac-pulse peaks [Hz]:", np.round(f_peaks, 1))
    plot_receiver(time, receiver, "Dirac pulse: lower-right receiver")
    plot_spectrum(receiver, model.dt, title="Dirac: receiver spectrum",
                  modes=theoretical_modes())
    return f_peaks


def task3_mode_10(n_periods=30):
    """Task 3: harmonic source at the (1,0) mode; axis pressure at four instants."""
    model = TLM2D()
    f = theoretical_axial_modes(n_modes=1)[0]            # (1,0): c0/(2L)
    period_steps = int(round(1.0 / (f * model.dt)))
    n_steps = n_periods * period_steps
    t = np.arange(n_steps) * model.dt
    source = harmonic_source(t, f, ramp_time=3.0 / f)

    # Instants in the last period: 0, T/4, T/2, 3T/4.
    first = n_steps - period_steps
    snap_idx = [first + k * period_steps // 4 for k in range(4)]
    _, _, snaps, _ = model.run(source, snapshots_at=snap_idx)

    plt.figure()
    for k, idx in enumerate(snap_idx):
        plot_axis_pressure(model, snaps[idx], label=f"t = {k}/4 T (+{n_periods - 1} T)")
    plt.title(f"Pressure along the axis, f = {f:.1f} Hz (1,0) mode")
    plt.legend()
    plt.tight_layout()


def measure_reflection(model, frequency, x_limit=None):
    """
    Drive the model harmonically at the left end and return the standing-wave
    result from the width-averaged amplitude along the pipe.
    """
    n_steps = int(round(SIMULATION_DURATION / model.dt))
    t = np.arange(n_steps) * model.dt
    # Slow fade-in (30 % of the run): in a lossless pipe (R = 1) free modes
    # never decay, so the gentler the start, the fewer of them are excited.
    source = harmonic_source(t, frequency, ramp_time=0.3 * SIMULATION_DURATION)
    _, _, _, line = model.run(source, record_line_y="mean")
    amp = harmonic_line_amplitude(line, model.dt, frequency)
    return model.x, amp, standing_wave_ratio(model.x, amp, x_limit=x_limit)


def task4_low_reflection(R=0.1):
    """Task 4: sweep response with R = 0.1 at both ends."""
    model = TLM2D(R_left=R, R_right=R)
    t, source, _, _ = linear_sweep_zero_crossings(model.dt)
    source = np.concatenate((source, np.zeros(int(round(RINGDOWN / model.dt)))))
    time, receiver, _, _ = model.run(source)
    plot_receiver(time, receiver, f"Sweep, R = {R}")
    plot_spectrum(receiver, model.dt, title=f"Sweep spectrum, R = {R}",
                  modes=theoretical_modes())


def task5_6_swr(frequencies=(200.0, 500.0), R_values=(1.0, 0.3)):
    """
    Tasks 5-6: standing-wave ratio at two frequencies below the first
    transverse mode (857 Hz), and comparison of |r| with R (and with G).
    Note: with R = 1 the pipe is lossless, so a true steady state does not
    exist; the result is only approximate (|r| close to 1).
    """
    for R in R_values:
        model = TLM2D(R_left=R, R_right=R)
        G = float(branch_to_wall_reflection(R))
        for f in frequencies:
            _, _, res = measure_reflection(model, f)
            print(f"R = {R:.2f} (G = {G:.3f}), f = {f:6.1f} Hz:")
            print(f"  First minimum:  |pmin,1| = {res['first_minimum']:.4g} "
                f"at x = {res['first_minimum_x']:.3f} m")
            print(f"  Second minimum: |pmin,2| = {res['second_minimum']:.4g} "
                f"at x = {res['second_minimum_x']:.3f} m")
            print(f"  Maximum:        |pmax|   = {res['maximum']:.4g} "
                f"at x = {res['maximum_between_minima_x']:.3f} m")
            print(f"  SWR = {res['SWR']:.3f}, |r| = {res['reflection_magnitude']:.3f}")


def task7_anechoic(frequencies=(200.0, 1000.0),
                   z_values=(0.02, 0.05, 0.08, 0.1, 0.15, 0.2, 0.3, 0.5, 1.0),
                   extension=1.0):
    """
    Task 7: the pipe is extended by 'extension' metres of lossy fluid
    (Kagawa 2.4, parameter z). The reflection factor is measured in the
    original 0-2 m part. The far end of the extension is rigid (R = 1),
    so everything that comes back has passed the lossy part twice.
    Three z profiles are tried: constant, linear ramp and quadratic ramp.
    """
    profiles = [("constant", False, 1.0), ("linear", True, 1.0), ("quadratic", True, 2.0)]
    results = []
    for name, ramp, power in profiles:
        for z in z_values:
            model = TLM2D(length=LENGTH + extension)
            model.set_loss_region(LENGTH, z, ramp=ramp, power=power)
            for f in frequencies:
                _, _, res = measure_reflection(model, f, x_limit=LENGTH)
                results.append((name, z, f, res["reflection_magnitude"]))
                print(f"{name:9s} z = {z:5.2f}, f = {f:6.1f} Hz: "
                      f"|r| = {res['reflection_magnitude']:.4f}")
    for f in frequencies:
        best = min((r for r in results if r[2] == f), key=lambda r: r[3])
        print(f"Lowest |r| at {f:.0f} Hz: {best[3]:.4f} "
              f"(profile = {best[0]}, z = {best[1]})")
    return results


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    # Comment out what you do not need; tasks 1-2 run in tens of seconds.
    #task1_sweep()
    #task2_dirac()
    #task3_mode_10()
    #task4_low_reflection(0.1)
    task5_6_swr()
    #task7_anechoic()
    plt.show()